<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Religion;
use App\Models\Denomination;
use Illuminate\Support\Facades\DB;

use Redirect;
use Validator;

class DenominationController extends Controller
{
    var   $rules;
    var   $messages;
    public function __construct()
    {
    //     $this->middleware(['permission:show_castes'])->only('index');
    //     $this->middleware(['permission:edit_caste'])->only('edit');
    //     $this->middleware(['permission:delete_caste'])->only('destroy');

        $this->rules = [
            'name'      => ['required', 'max:255'],
            'religion'  => ['required'],
        ];

        $this->messages = [
            'name.required'     => translate('Name is required'),
            'name.max'          => translate('Max 255 characters'),
            'religion.required' => translate('Religion is required'),
        ];
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $sort_search  = null;
        $denominations       = Denomination::latest();
        // $denominations    = DB::table('denomination')->latest();
        $religions    = Religion::all();

        if ($request->has('search')) {
            $sort_search  = $request->search;
            $denominations       = $denominations->where('name', 'like', '%' . $sort_search . '%');
        }
        $denominations = $denominations->paginate(10);
        // dd($denominations);
        return view('admin.member_profile_attributes.denominations.index', compact('denominations', 'religions', 'sort_search'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $rules      = $this->rules;
        $messages   = $this->messages;
        $validator  = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            flash(translate('Sorry! Something went wrong'))->error();
            return Redirect::back()->withErrors($validator);
        }

        // $denomination              =   DB::table('denomination');
        $denomination              =   new Denomination;
        $denomination->name        = $request->name;
        $denomination->religion_id = $request->religion;
        if ($denomination->save()) {
            flash('New denomination has been added successfully')->success();
            return redirect()->route('denominations.index');
        } else {
            flash('Sorry! Something went wrong.')->error();
            return back();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $denomination          =   Denomination::findOrFail(decrypt($id));
        $religions      = Religion::all();
        return view('admin.member_profile_attributes.denominations.edit', compact('denomination', 'religions'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $rules      = $this->rules;
        $messages   = $this->messages;
        $validator  = Validator::make($request->all(), $rules, $messages);

        if ($validator->fails()) {
            flash(translate('Sorry! Something went wrong'))->error();
            return Redirect::back()->withErrors($validator);
        }

        $denomination              = Denomination::findOrFail($id);
        $denomination->name        = $request->name;
        $denomination->religion_id = $request->religion;
        if ($denomination->save()) {
            flash('denomination info has been updated successfully')->success();
            return redirect()->route('denominations.index');
        } else {
            flash('Sorry! Something went wrong.')->error();
            return back();
        }
    }

    public function caste_bulk_delete(Request $request)
    {
        if ($request->id) {
            foreach ($request->id as $id) {
                $this->destroy($id);
            }
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $denomination =  Denomination::findOrFail($id);
        foreach ($denomination->sub_castes as $key => $sub_caste) {
            $sub_caste->delete();
        }
        if ( Denomination::destroy($id)) {
            flash('Denomination info has been deleted successfully')->success();
            return redirect()->route('denominations.index');
        } else {
            flash('Sorry! Something went wrong.')->error();
            return back();
        }
    }

    // Get denominations by religion
    public function get_caste_by_religion(Request $request)
    {
        $denominations =   Denomination::where('religion_id', $request->religion_id)->get();
        return $denominations;
    }
}
