<div class="card-header bg-dark text-white">
    <h5 class="mb-0 h6">{{translate('Physical Attributes')}}</h5>
</div>
<div class="card-body">
    <form action="{{ route('physical-attribute.update', $member->id) }}" method="POST">
        <input name="_method" type="hidden" value="PATCH">
        @csrf

        <div class="form-group row">
            <div class="col-md-6">
                <label for="height">{{translate('Height')}}</label>
                <select name="height" class="form-control" required>
                    <option value="">{{translate('Select Height')}}</option>
                    @foreach(range(120, 220, 5) as $height)
                        <option value="{{ $height }}" {{ (isset($member->physical_attributes->height) && $member->physical_attributes->height == $height) ? 'selected' : '' }}>
                            {{ $height }} cm
                        </option>
                    @endforeach
                </select>
                @error('height')
                    <small class="form-text text-danger">{{ $message }}</small>
                @enderror
            </div>

            <div class="col-md-6">
                <label for="weight">{{translate('Weight')}}</label>
                <select name="weight" class="form-control" required>
                    <option value="">{{translate('Select Weight')}}</option>
                    @foreach(range(40, 150, 5) as $weight)
                        <option value="{{ $weight }}" {{ (isset($member->physical_attributes->weight) && $member->physical_attributes->weight == $weight) ? 'selected' : '' }}>
                            {{ $weight }} kg
                        </option>
                    @endforeach
                </select>
                @error('weight')
                    <small class="form-text text-danger">{{ $message }}</small>
                @enderror
            </div>
        </div>

        <div class="form-group row">
            <div class="col-md-6">
                <label for="eye_color">{{translate('Eye color')}}</label>
                <select name="eye_color" class="form-control" required>
                    <option value="">{{translate('Select Eye Color')}}</option>
                    @foreach(['Black', 'Brown', 'Blue', 'Green', 'Hazel', 'Grey'] as $color)
                        <option value="{{ $color }}" {{ ($member->physical_attributes->eye_color ?? '') == $color ? 'selected' : '' }}>{{ $color }}</option>
                    @endforeach
                </select>
                @error('eye_color')
                    <small class="form-text text-danger">{{ $message }}</small>
                @enderror
            </div>

            <div class="col-md-6">
                <label for="hair_color">{{translate('Hair Color')}}</label>
                <select name="hair_color" class="form-control" required>
                    <option value="">{{translate('Select Hair Color')}}</option>
                    @foreach(['Black', 'Brown', 'Blonde', 'Red', 'Grey', 'White'] as $color)
                        <option value="{{ $color }}" {{ ($member->physical_attributes->hair_color ?? '') == $color ? 'selected' : '' }}>{{ $color }}</option>
                    @endforeach
                </select>
                @error('hair_color')
                    <small class="form-text text-danger">{{ $message }}</small>
                @enderror
            </div>
        </div>

        <div class="form-group row">
            <div class="col-md-6">
                <label for="complexion">{{translate('Complexion')}}</label>
                <select name="complexion" class="form-control" required>
                    <option value="">{{translate('Select Complexion')}}</option>
                    @foreach(['Fair', 'Medium', 'Olive', 'Brown', 'Dark'] as $complexion)
                        <option value="{{ $complexion }}" {{ ($member->physical_attributes->complexion ?? '') == $complexion ? 'selected' : '' }}>{{ $complexion }}</option>
                    @endforeach
                </select>
                @error('complexion')
                    <small class="form-text text-danger">{{ $message }}</small>
                @enderror
            </div>

            <div class="col-md-6">
                <label for="blood_group">{{translate('Blood Group')}}</label>
                <select name="blood_group" class="form-control" required>
                    <option value="">{{translate('Select Blood Group')}}</option>
                    @foreach(['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'] as $group)
                        <option value="{{ $group }}" {{ ($member->physical_attributes->blood_group ?? '') == $group ? 'selected' : '' }}>{{ $group }}</option>
                    @endforeach
                </select>
                @error('blood_group')
                    <small class="form-text text-danger">{{ $message }}</small>
                @enderror
            </div>
        </div>

        <div class="form-group row">
            <div class="col-md-6">
                <label for="body_type">{{translate('Body Type')}}</label>
                <select name="body_type" class="form-control" required>
                    <option value="">{{translate('Select Body Type')}}</option>
                    @foreach(['Slim', 'Athletic', 'Average', 'Heavy', 'Muscular'] as $type)
                        <option value="{{ $type }}" {{ ($member->physical_attributes->body_type ?? '') == $type ? 'selected' : '' }}>{{ $type }}</option>
                    @endforeach
                </select>
                @error('body_type')
                    <small class="form-text text-danger">{{ $message }}</small>
                @enderror
            </div>

            <div class="col-md-6">
                <label for="body_art">{{translate('Body Art')}}</label>
                <select name="body_art" class="form-control" required>
                    <option value="">{{translate('Select Body Art')}}</option>
                    @foreach(['None', 'Tattoo', 'Piercing', 'Tattoo & Piercing'] as $art)
                        <option value="{{ $art }}" {{ ($member->physical_attributes->body_art ?? '') == $art ? 'selected' : '' }}>{{ $art }}</option>
                    @endforeach
                </select>
                @error('body_art')
                    <small class="form-text text-danger">{{ $message }}</small>
                @enderror
            </div>
        </div>

        <div class="form-group row">
            <div class="col-md-6">
                <label for="disability">{{translate('Disability')}}</label>
                <select name="disability" class="form-control">
                    <option value="">{{translate('Select Disability Status')}}</option>
                    @foreach(['None', 'Physical', 'Visual', 'Hearing', 'Other'] as $disability)
                        <option value="{{ $disability }}" {{ ($member->physical_attributes->disability ?? '') == $disability ? 'selected' : '' }}>{{ $disability }}</option>
                    @endforeach
                </select>
                @error('disability')
                    <small class="form-text text-danger">{{ $message }}</small>
                @enderror
            </div>
        </div>

        <div class="text-right">
            <button type="submit" class="btn btn-primary btn-sm">{{translate('Update')}}</button>
        </div>
    </form>
</div>
