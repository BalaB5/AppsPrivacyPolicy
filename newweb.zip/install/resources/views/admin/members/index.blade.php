@extends('admin.layouts.app')

@section('content')
<div class="aiz-titlebar mt-2 mb-4">
    <div class="row align-items-center">
        <div class="col-md-6">
            <h1 class="h3">{{ translate('Members') }}</h1>
        </div>
        @can('create_member')
            <div class="col-md-6 text-right">
                <a href="{{ route('members.create') }}" class="btn btn-circle btn-primary">
                    {{ translate('Add New Member') }}
                </a>
            </div>
        @endcan
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header row gutters-5">
                <div class="col text-center text-md-left">
                    <h5 class="mb-md-0 h6">{{ translate('All members') }}</h5>
                </div>

                {{-- Filter and Search --}}
                <div class="col-md-3">
                    <form id="sort_members" action="" method="GET">
                        <div class="input-group input-group-sm mb-2">
                            <input type="text" class="form-control" id="search" name="search"
                                @isset($sort_search) value="{{ $sort_search }}" @endisset
                                placeholder="{{ translate('Type first name / last name / ID & Enter') }}">
                        </div>
                        <div class="input-group input-group-sm">
                            <select class="form-control" name="member_type" onchange="this.form.submit();">
                                <option value="">{{ translate('All') }}</option>
                                <option value="1" {{ request('member_type') == '1' ? 'selected' : '' }}>{{ translate('Normal') }}</option>
                                <option value="2" {{ request('member_type') == '2' ? 'selected' : '' }}>{{ translate('Premium') }}</option>
                            </select>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card-body">
                <table class="table aiz-table mb-0">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="select_all"></th>
                            <th>#</th>
                            <th>{{ translate('Image') }}</th>
                            <th>{{ translate('Member Code') }}</th>
                            <th data-breakpoints="md">{{ translate('Name') }}</th>
                            <th data-breakpoints="md">{{ translate('Gender') }}</th>
                            @if(get_setting('member_verification') == 1)
                                <th data-breakpoints="md">{{ translate('Verification Status') }}</th>
                            @endif
                            <th data-breakpoints="md">{{ translate('Member Type') }}</th>
                            <th data-breakpoints="md">{{ translate('Member Since') }}</th>
                            <th data-breakpoints="md">{{ translate('Member Status') }}</th>
                            <th class="text-right">{{ translate('Options') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($members as $key => $member)
                            <tr>
                                <td><input type="checkbox" class="member_checkbox" name="selected_members[]" value="{{ $member->id }}"></td>
                                <td>{{ $key + 1 + ($members->currentPage() - 1) * $members->perPage() }}</td>
                                <td>
                                    @if(uploaded_asset($member->photo) != null)
                                        <img class="img-md" src="{{ uploaded_asset($member->photo) }}" height="45px" alt="{{ translate('photo') }}">
                                    @else
                                        <img class="img-md" src="{{ asset('assets/img/avatar-place.png') }}" height="45px" alt="{{ translate('photo') }}">
                                    @endif
                                </td>
                                <td>{{ $member->code }}</td>
                                <td>{{ $member->first_name . ' ' . $member->last_name }}</td>
                                <td>
                                    @if($member->member && $member->member->gender == 1)
                                        {{ translate('Male') }}
                                    @elseif($member->member && $member->member->gender == 2)
                                        {{ translate('Female') }}
                                    @else
                                        {{ '' }}
                                    @endif
                                </td>
                                @if(get_setting('member_verification') == 1)
                                    <td>
                                        @if($member->approved == 1)
                                            <span class="badge badge-inline badge-success">{{ translate('Approved') }}</span>
                                        @elseif($member->verification_info != null)
                                            <span class="badge badge-inline badge-info">{{ translate('Pending') }}</span>
                                        @else
                                            <span class="badge badge-inline badge-warning">{{ translate('No Request') }}</span>
                                        @endif
                                    </td>
                                @endif
                                <td>
                                    @if($member->membership == 1)
                                        <span class="badge badge-inline badge-info">{{ translate('Normal') }}</span>
                                    @else
                                        <span class="badge badge-inline badge-success">{{ translate('Premium') }}</span>
                                    @endif
                                </td>
                                <td>{{ date('d-m-Y', strtotime($member->created_at)) }}</td>
                                <td>
                                    @if($member->deactivated == 0)
                                        <span class="badge badge-inline badge-success">{{ translate('Active') }}</span>
                                    @else
                                        <span class="badge badge-inline badge-danger">{{ translate('Deactivated') }}</span>
                                    @endif
                                </td>
                                <td class="text-right">
                                    <div class="btn-group mb-2">
                                        <div class="btn-group">
                                            <button type="button" class="btn py-0" data-toggle="dropdown" aria-expanded="false">
                                                <i class="las la-ellipsis-v"></i>
                                            </button>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                @can('share_member_profile')
                                                    <a class="dropdown-item" href="{{ route('members.show', encrypt($member->id)) }}">{{ translate('View') }}</a>
                                                @endcan
                                                @can('edit_member')
                                                    <a class="dropdown-item" href="{{ route('members.edit', encrypt($member->id)) }}">{{ translate('Edit') }}</a>
                                                @endcan
                                                @can('block_member')
                                                    @if($member->blocked == 0)
                                                        <a class="dropdown-item" onclick="block_member({{ $member->id }})" href="javascript:void(0);">{{ translate('Block') }}</a>
                                                    @else
                                                        <a class="dropdown-item" onclick="unblock_member({{ $member->id }})" href="javascript:void(0);">{{ translate('Unblock') }}</a>
                                                    @endif
                                                @endcan
                                                @can('approve_member')
                                                    @if(get_setting('member_verification') == 1 && $member->verification_info != null)
                                                        <a class="dropdown-item" href="{{ route('member.show_verification_info', encrypt($member->id)) }}">{{ translate('View Verification Info') }}</a>
                                                    @endif
                                                @endcan
                                                @can('update_member_package')
                                                    <a class="dropdown-item" onclick="package_info({{ $member->id }})" href="javascript:void(0);">{{ translate('Package') }}</a>
                                                @endcan
                                                <a class="dropdown-item" onclick="wallet_balance_update({{ $member->id }}, {{ $member->balance }})" href="javascript:void(0);">{{ translate('Wallet Balance') }}</a>
                                                @can('login_as_member')
                                                    <a href="{{ route('members.login', encrypt($member->id)) }}" class="dropdown-item">{{ translate('Login as this Member') }}</a>
                                                @endcan
                                                @can('delete_member')
                                                    <a class="dropdown-item confirm-delete" data-href="{{ route('members.destroy', $member->id) }}">{{ translate('Delete') }}</a>
                                                @endcan
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                <div class="aiz-pagination">
                    {{ $members->appends(request()->input())->links() }}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('script')
<script type="text/javascript">
    function sort_members(el) {
        $('#sort_members').submit();
    }

    function package_info(id) {
        $.post('{{ route('members.package_info') }}', {
            _token: '{{ @csrf_token() }}',
            id: id
        }, function(data) {
            $('.create_edit_modal_content').html(data);
            $('.create_edit_modal').modal('show');
        });
    }

    function block_member(id) {
        $('.member-block-modal').modal('show');
        $('#block_member_id').val(id);
        $('#block_status').val(1);
    }

    function unblock_member(id) {
        $('#unblock_member_id').val(id);
        $('#unblock_block_status').val(0);
        $.post('{{ route('members.blocking_reason') }}', {
            _token: '{{ @csrf_token() }}',
            id: id
        }, function(data) {
            $('.member-unblock-modal').modal('show');
            $('#block_reason').html(data);
        });
    }

    function wallet_balance_update(id, balance) {
        $('.member_wallet_balance_modal').modal('show');
        $('#user_id_wallet_balance').val(id);
        $('#member_wallet_balance').val(balance);
    }

    // Select All Checkbox
    $(document).on('change', '#select_all', function() {
        $('.member_checkbox').prop('checked', this.checked);
    });
</script>
@endsection
